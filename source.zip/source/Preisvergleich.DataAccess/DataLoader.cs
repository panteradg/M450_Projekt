﻿using Newtonsoft.Json;

namespace Preisvergleich.DataAccess
{
    public class DataLoader
    {
        public DataLoader()
        {
            using (StreamReader reader = new StreamReader("../../../../Preisvergleich.DataAccess/inputData.json"))
            {
                string json = reader.ReadToEnd();
                Products = JsonConvert.DeserializeObject<List<string>>(json);
                reader.Close();
            }
        }

        public void AddProduct(string product, Website website, decimal price)
        {
            ProductsFromWebsite.Add(new ProductFromWebsite()
            {
                Price = price,
                Product = product,
                Website = website,
                Timestamp = DateTime.Now
            });
        }

        public void SaveData()
        {
            List<List<ProductFromWebsite>> productFromWebsiteListList = new List<List<ProductFromWebsite>>();
            using (StreamReader reader = new StreamReader("../../../../Preisvergleich.DataAccess/outputData.json"))
            {
                string outputDataJson = reader.ReadToEnd();
                productFromWebsiteListList = JsonConvert.DeserializeObject<List<List<ProductFromWebsite>>>(outputDataJson);
                reader.Close();
            }

            productFromWebsiteListList.Add(ProductsFromWebsite);
            string json = JsonConvert.SerializeObject(productFromWebsiteListList, Formatting.Indented);

            File.WriteAllLines("../../../../Preisvergleich.DataAccess/outputData.json", new[] { json });
            ProductsFromWebsite.Clear();
        }

        public List<ProductFromWebsite> ProductsFromWebsite { get; set; } = new List<ProductFromWebsite>();
        public List<string> Products { get; }
    }
}